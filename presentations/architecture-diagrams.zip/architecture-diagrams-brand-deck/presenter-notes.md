# Presenter notes

## 1. Creating architecturediagrams with AITools, skills and approaches

This is a practitioner story, not a model benchmark. We will introduce the options and a sample prompt, then see the supplied Cowork output and the six recent Fabric batch diagrams, ending with CSA style. The deck follows the GitHub Brand Toolkit's neutral/green palette and Mona Sans typography; it is an independent presentation, not an endorsement.

## 2. Choose the approach for the job.

Cowork is a product/workspace, not a peer diagram notation. The six other rows are authoring approaches used in our Astra-led session. Aymen pitch and iterate are two original skills used together in one approach. Astra + draw.io is the deliberate no-skill baseline, not a missing installation. Shared MCPs refers to the toolkit's common content-research setup, not independently verified use of both servers for every output; official web retrieval and GitHub CLI were also used. Excalidraw skill guidance is externally referenced because its separate repository has no explicit license; it is not bundled. These use cases are practical suggestions, not rankings. The supplied Cowork screenshot does not record an exact Claude model/version. Anthropic's current Cowork page says the capabilities are being integrated into Claude; Cowork is retained here as the user's workflow label. Source: https://claude.com/product/cowork.

## 3. Sample prompt

Use this short sample prompt to introduce the demo. The six Astra outputs used a more detailed common batch brief with 15 components and 17 relationships, retained in downloads/fabric-six-approaches.zip. The supplied Cowork image has a broader scope; this sample prompt is not a claim that every output was generated from exactly these words alone.

## 4. 01 / Cowork

The user supplied this image as the Cowork result. It is preserved byte-for-byte, not recreated or technically endorsed. It includes a single workspace/capacity framing, multiple ingestion options, OneLake layers, notebooks/MLflow, batch scoring, online model endpoints, AI functions, BI and governance. Its scope and prompt differ from the 15-component batch brief. We cannot infer the exact Claude model, plugins, prompts, MCP calls, source fidelity or generation cost from the screenshot. Only a PNG was supplied; no native editable Cowork source is claimed. Treat detailed capability statements as assertions to verify for a concrete design.

## 5. 02 / Azure Diagrams

The original Python diagrams generator and Graphviz source are retained. The Azure Diagrams skill was applied directly from the repository. For this Fabric workload, official Fabric icons were used rather than substituting Azure ML services. Invisible Graphviz edges constrain layout only; the 17 visible relationships come from the common contract. Automatic layout needed several revisions for ordering, whitespace and captions. This is code-editable, not native drag-and-drop draw.io. The standalone PNG is easiest to share; retain accompanying icons for the SVG.

## 6. 03 / Excalidraw

The scene was hand-authored in sections using pinned upstream guidance, then normalized and exported with the Excalidraw application library. Its clean styling follows that guidance; sketch-like roughness is not mandatory. A custom prediction-record example makes the output concrete without presenting it as a built-in Fabric schema. This version has the same 15 components and 17 relationships. No unlicensed skill source was copied into the toolkit or deliverable. The independent browser exporter downloaded remote libraries; local rendering does not mean all processing or model inference was offline.

## 7. 04 / Aymen: pitch + iterate

Two GPT-6 Astra research contexts covered ingestion/training and scoring/consumption before the pitch. The original skills prescribe A5, meaningful ninefold XML growth before correction passes, and at least four reviews. This latest run completed four review passes but reached only 38,303 / 16,500 = 2.3214x meaningful pass-1 XML. It continued past the unmet gate as a documented deviation, not full original-skill compliance. Do not confuse this run with the earlier MLOps comparison where the user expressly waived the growth rule. We did not modify the original skills or add padding to satisfy a quota. Small A5 annotations need enlargement. Sources and all review pairs are in the bundle.

## 8. 05 / Mermaid

The full portrait flow is shown on the left; the right image is a clearly labeled crop from the same PNG for slide readability. No components have been removed from the underlying diagram. Click either image for the full scrollable original. Mermaid is easy to review as text and regenerate, but automatic layout and dense long flows are less suited to a single landscape slide. The native .mmd, SVG and PNG are in the source ZIP. This is the general Mermaid-diagrams skill, not the earlier Pretty Mermaid renderer comparison.

## 9. 06 / Astra + draw.io

A fresh independent context received the common brief but was prohibited from reading diagram skills, examples, helpers or sibling outputs. It created native draw.io shapes and attached connectors. The parent then exported using the common local draw.io application and requested one small annotation move after visual inspection. Using an export wrapper is not the same as skill-guided source generation. This is a credible baseline, not an intentionally weak straw man. A strong result does not prove that skills never help.

## 10. 07 / CSA style

This current official-icon Fabric example was regenerated with the CSA helpers; it was not a new independent invention. That reuse is one intended benefit of a package with examples. The style is inspired by the Microsoft Azure Architecture Center: service icons, purposeful section bands, meaningful workflow numbers and perimeter feedback. Logical phases are distinct from workspace ownership. It is an independently authored skill, not an official Microsoft diagram standard or endorsement.
