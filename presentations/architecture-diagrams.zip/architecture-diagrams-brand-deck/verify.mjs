import {mkdirSync, writeFileSync} from 'node:fs';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {join} from 'node:path';
import assert from 'node:assert/strict';
const {chromium} = await import(pathToFileURL(process.argv[2]).href);
const root = fileURLToPath(new URL('.', import.meta.url));
const url = process.argv[3] || 'http://127.0.0.1:8872/';
const origin = new URL(url).origin;
const output = join(root, 'checks');
mkdirSync(output, {recursive:true});
const browser = await chromium.launch({
  executablePath:process.env.EDGE_PATH || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless:true
});
const errors = [], external = [];
const report = {slides:[],viewers:[],offline:false,mobile:false,notes:false};
try {
  const context = await browser.newContext({viewport:{width:1600,height:900}});
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  page.on('response', response => {if(response.status() >= 400) errors.push(`${response.status()} ${response.url()}`);});
  page.on('request', request => {if(/^https?:/.test(request.url()) && new URL(request.url()).origin !== origin) external.push(request.url());});
  await page.goto(url);
  await page.waitForFunction(() => window.Reveal?.isReady());
  await page.evaluate(async () => {await document.fonts.ready; Reveal.configure({transition:'none'});});
  assert.equal(await page.evaluate(() => Reveal.getTotalSlides()),10);
  assert.deepEqual(await page.locator('.slides > section').evaluateAll(slides=>slides.map(slide=>slide.id)),
    ['opening','options','demo','cowork','azure','excalidraw','aymen','mermaid','baseline','csa']);
  assert.doesNotMatch(await page.locator('.slides').textContent(),/Private repository|Private access required|repository is private/i);
  assert.equal(await page.locator('#content-mcps, #brief').count(),0);
  assert.equal(await page.locator('.slides > section').nth(1).getAttribute('id'),'options');
  assert.equal(await page.locator('#options tbody tr').count(),7);
  assert.deepEqual(await page.locator('#options th').allTextContents(),['Skill or approach','Origin / source','Best suited for']);
  assert.equal(await page.locator('#options tbody tr').first().locator('td').nth(1).textContent(),'');
  assert.equal(await page.locator('#options tbody td:nth-child(2) a').count(),7);
  assert.ok(await page.locator('#options tbody td:nth-child(2) a').evaluateAll(links=>links.every(link=>link.href.startsWith('https://') && link.target==='_blank' && link.rel.includes('noopener'))));
  assert.equal(await page.locator('#options .new-skill-label').textContent(),'New skill created');
  assert.equal(await page.locator('.slides > section').nth(2).getAttribute('id'),'demo');
  assert.equal(await page.locator('.slides > section').nth(3).getAttribute('id'),'cowork');
  assert.equal(await page.locator('#cowork .subhead').count(),0);
  assert.equal(await page.locator('#cowork .diagram-caption').count(),0);
  assert.equal(await page.locator('.diagram-caption').count(),6);
  assert.ok(await page.locator('.diagram-caption').evaluateAll(captions=>captions.every(caption=>
    caption.children.length===1 && getComputedStyle(caption.firstElementChild).color==='rgb(82, 96, 87)')));
  assert.equal(await page.locator('#demo .demo-prompt').textContent(),"Draw an architecture for Fabric's end-to-end data science");
  assert.ok(await page.locator('#demo .demo-prompt').evaluate(element=>getComputedStyle(element).fontFamily.includes('monospace') && getComputedStyle(element).fontWeight==='400'));
  assert.equal(await page.evaluate(() => document.fonts.check('30px "Mona Sans"')),true);
  for(let i=0;i<10;i++) {
    await page.evaluate(index => Reveal.slide(index),i);
    await page.waitForTimeout(100);
    const state = await page.evaluate(() => {
      const slide = Reveal.getCurrentSlide(), bounds = slide.getBoundingClientRect();
      const overflow = [...slide.querySelectorAll('h1,h2,h3,p,blockquote,table,.model-line,.panel,.pipeline,.loop,.timeline,.diagram-trigger')]
        .filter(e=>!e.closest('.notes'))
        .filter(e=>{const r=e.getBoundingClientRect();return r.width && r.height &&
          (r.left<bounds.left-2 || r.right>bounds.right+2 || r.top<bounds.top-2 || r.bottom>bounds.bottom+2);})
        .map(e=>e.textContent.trim().slice(0,100));
      return {id:slide.id,title:slide.querySelector('h1,h2').textContent,overflow,
        loaded:[...slide.querySelectorAll('img')].every(e=>e.complete && e.naturalWidth>0),
        notes:slide.querySelector('.notes')?.textContent.trim()};
    });
    await page.screenshot({path:join(output,`slide-${String(i+1).padStart(2,'0')}.png`)});
    report.slides.push(state);
    assert.deepEqual(state.overflow,[],`${state.id}: overflow`);
    assert.ok(state.loaded,`${state.id}: missing image`);
    assert.ok(state.notes,`${state.id}: missing notes`);
    const triggers=page.locator('.present .diagram-trigger');
    for(let n=0;n<await triggers.count();n++) {
      const trigger=triggers.nth(n);
      await trigger.click();
      await page.waitForFunction(()=>document.getElementById('diagram-viewer').open &&
        document.getElementById('viewer-image').complete && document.getElementById('viewer-image').naturalWidth>0);
      const before=await page.locator('#viewer-image').evaluate(e=>e.getBoundingClientRect().width);
      await page.locator('#zoom-in').click();
      assert.ok(await page.locator('#viewer-image').evaluate(e=>e.getBoundingClientRect().width)>before);
      await page.locator('#zoom-fit').click();
      assert.ok(await page.locator('.viewer-scroll').evaluate(e=>e.scrollWidth<=e.clientWidth+1 && e.scrollHeight<=e.clientHeight+1));
      await page.locator('#zoom-readable').click();
      await page.keyboard.press('Escape');
      assert.equal(await page.locator('#diagram-viewer').evaluate(e=>e.open),false);
      assert.equal(await page.evaluate(()=>Reveal.getIndices().h),i);
      assert.ok(await trigger.evaluate(e=>document.activeElement===e));
      report.viewers.push(`${state.id}:${n}`);
    }
  }
  await page.evaluate(()=>Reveal.slide(0));
  await page.keyboard.press('ArrowRight');
  assert.equal(await page.evaluate(()=>Reveal.getIndices().h),1);
  await page.keyboard.press('ArrowLeft');
  assert.equal(await page.evaluate(()=>Reveal.getIndices().h),0);
  await page.locator('#overview').click();
  assert.ok(await page.evaluate(()=>Reveal.isOverview()));
  await page.locator('#overview').click();
  const popupPromise=page.waitForEvent('popup');
  await page.keyboard.press('s');
  const notes=await popupPromise;
  await notes.waitForLoadState('domcontentloaded');
  await notes.waitForFunction(()=>document.body.innerText.includes('practitioner story'),{timeout:10000});
  await notes.close();
  report.notes=true;
  await page.setViewportSize({width:390,height:844});
  await page.evaluate(()=>Reveal.slide([...Reveal.getSlides()].findIndex(slide=>slide.id==='mermaid')));
  await page.locator('.present .diagram-trigger').first().click();
  await page.waitForFunction(()=>document.getElementById('viewer-image').complete);
  assert.ok(await page.locator('#diagram-viewer').evaluate(e=>e.getBoundingClientRect().right<=innerWidth+1));
  await page.screenshot({path:join(output,'mobile-viewer.png')});
  await page.locator('#close-viewer').click();
  report.mobile=true;
  await context.setOffline(true);
  const offline=await context.newPage();
  offline.on('pageerror',error=>errors.push(error.message));
  await offline.goto(pathToFileURL(join(root,'index.html')).href);
  await offline.waitForFunction(()=>window.Reveal?.isReady());
  assert.equal(await offline.evaluate(()=>Reveal.getTotalSlides()),10);
  assert.ok(await offline.evaluate(()=>[...document.images].filter(e=>e.id!=='viewer-image').every(e=>e.complete && e.naturalWidth>0)));
  report.offline=true;
  assert.deepEqual(errors,[]);
  assert.deepEqual(external,[]);
  report.errors=errors;report.externalRequests=external;
  writeFileSync(join(output,'verification.json'),JSON.stringify(report,null,2));
  writeFileSync(join(root,'presenter-notes.md'),'# Presenter notes\n\n'+report.slides.map((s,i)=>`## ${i+1}. ${s.title}\n\n${s.notes}\n`).join('\n'));
  console.log(`PASS: 10 slides, ${report.viewers.length} viewers, notes, navigation, mobile and offline.`);
} finally {
  writeFileSync(join(output,'last-run.json'),JSON.stringify({report,errors,external},null,2));
  await browser.close();
}
