"""Package the verified offline deck without tools or temporary downloads."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package():
    verification = json.loads((ROOT / "checks" / "verification.json").read_text())
    assert len(verification["slides"]) == 10
    assert len(verification["viewers"]) == 8
    assert verification["offline"] and verification["mobile"] and verification["notes"]
    assert not verification["errors"] and not verification["externalRequests"]
    provenance = json.loads((ROOT / "provenance.json").read_text())
    for image in provenance["original_images"]:
        assert sha(ROOT / image["file"]) == image["sha256"], image["file"]

    screenshots = sorted((ROOT / "checks").glob("slide-*.png"))
    if screenshots:
        assert len(screenshots) == 10
        sheet = Image.new("RGB", (1680, 800), "#e4ebe6")
        draw = ImageDraw.Draw(sheet)
        font = ImageFont.truetype("arial.ttf", 18)
        for i, path in enumerate(screenshots):
            x, y = 20 + (i % 4) * 415, 15 + (i // 4) * 265
            with Image.open(path) as image:
                sheet.paste(ImageOps.contain(image.convert("RGB"), (395, 223),
                                            Image.Resampling.LANCZOS), (x, y + 25))
            draw.text((x, y), f"{i + 1:02}", font=font, fill="#232925")
        sheet.save(ROOT / "slide-overview.png")

    files = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative in {"manifest.json", "font-download.zip"}:
            continue
        if relative.startswith("checks/") and relative != "checks/verification.json":
            continue
        if path.suffix in {".js", ".mjs", ".html", ".css", ".md", ".json", ".py", ".txt"}:
            text = path.read_text(encoding="utf-8")
            assert not re.search(r"[A-Za-z]:[\\/]+Users[\\/]", text, re.I), relative
            assert not re.search(r"gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}", text), relative
        files.append(path)
    manifest = [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size,
                 "sha256": sha(p)} for p in files]
    manifest_path = ROOT / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT.parent / "architecture-diagrams-brand-deck.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for path in files + [manifest_path]:
            z.write(path, "architecture-diagrams-brand-deck/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for record in manifest:
            data = z.read("architecture-diagrams-brand-deck/" + record["path"])
            assert hashlib.sha256(data).hexdigest() == record["sha256"]
    print(json.dumps({"slides": 10, "files": len(files) + 1, "archive_bytes": archive.stat().st_size,
                      "archive_sha256": sha(archive)}))


if __name__ == "__main__":
    package()
