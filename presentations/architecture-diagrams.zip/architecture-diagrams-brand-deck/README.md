# Architecture diagrams: models, tools and skills

A 10-slide Reveal.js presentation using GitHub Brand Toolkit-informed
typography and colors. It is an independent presentation, not an official
GitHub or Microsoft deck.

## Open

Open `index.html` directly for an offline presentation, or serve this folder:

```powershell
python -m http.server 8872 --bind 127.0.0.1
```

Then open `http://127.0.0.1:8872/`. A local server is recommended for the
presenter-notes popup. No package installation is required to present.

- Arrow keys: move through slides.
- Overview button or Escape: slide overview.
- S: presenter notes (allow the popup).
- F: fullscreen.
- Click any diagram: zoomable original; use Fit, Readable, +, - and Close.
- Escape inside the viewer: close it without moving slides.
- `presenter-notes.md`: readable notes without a popup.
- `downloads/fabric-six-approaches.zip`: editable sources and evidence.

The existing presentation on port 8871 is separate and was not modified.

## Structure and provenance

1. Options, origins/original-source links and use cases, followed by the demo sample prompt.
2. One slide each for Cowork, Azure Diagrams, Excalidraw, Aymen pitch/iterate,
   Mermaid, no-skill draw.io and CSA.

The Cowork PNG was supplied by the user and copied without alteration. Its
scope includes streaming, online serving, AI and governance; it is not an
identical-brief seventh trial. No editable Cowork source or exact model is
available. Its embedded product claims are not independently validated here.

The other six PNGs are the completed Astra-led batch-diagram comparison:
15 components and 17 relationships. Their original pixels are retained.
Mermaid additionally has two clearly labeled detail crops to aid reading;
both open the complete original. CSA regenerates the updated official-icon
example. Aymen completed four reviews but did not meet the original 9x
meaningful XML growth gate (2.3214x achieved). The deck does not conceal that.

Microsoft Learn and GitHub MCP are the toolkit's opt-in context tools. This
does not claim those example configurations were activated, or that all
research used MCP. Official web retrieval, research agents and GitHub CLI
were also used.

## Brand and licenses

Reviewed 2026-11-02:

- https://brand.github.com/foundations/color
- https://brand.github.com/foundations/typography
- https://brand.github.com/foundations/logo

The deck uses GitHub green `#0FBF3E`, the official neutral palette, restrained
Copilot purple, normal-width Mona Sans, no artificial tracking and no logo
adaptations. It does not redistribute brand illustrations or use GitHub's
logo as the project's identity.

- Reveal.js 6.0.2: local assets, original MIT notice at `vendor/reveal/LICENSE`.
- Mona Sans v2.0.27: original normal-width variable WOFF2 and `assets/fonts/OFL.txt`.
  Source: https://github.com/github/mona-sans/releases/tag/v2.0.27.
- Microsoft Fabric icon notice: `assets/LICENSE-Fabric`.
- CSA original layout/code notice: `sources/LICENSE-CSA.txt`.
- Further diagram/source notices remain inside the six-approach ZIP.
- User-supplied Cowork screenshot is included for this requested presentation;
  no separate redistribution license is asserted.

There are no automatic external requests when presenting. External reference
links are deliberate actions. This says nothing about whether the model
inference that produced the diagrams ran locally.

## Editing and verification

Edit slide text and presenter notes in `deck.js`, and styles in `deck.css`.
The original PNGs are under `assets/`; native diagrams are inside the source ZIP.

The optional `verify.mjs` accepts an existing Playwright module path and a URL:

```powershell
node .\verify.mjs "<absolute-path-to-playwright-core\index.mjs>" "http://127.0.0.1:8872/"
```

It uses installed Edge on Windows (or `EDGE_PATH`), writes screenshots and
notes, and checks slide bounds, image loads, navigation, viewer controls,
speaker notes, mobile use and offline opening. It does not install dependencies.
After substantive edits, visually inspect the screenshots as well.
