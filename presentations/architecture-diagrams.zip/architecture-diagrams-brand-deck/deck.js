const repo = 'https://github.com/suzungg/csa-architecture-diagram-skills';
const intro = `
<section id="opening" class="cover dark" data-background-color="#101411">
  <p class="eyebrow">Architecture diagrams / Models, tools and skills</p>
  <h1>Creating architecture<br>diagrams with AI<br><em>Tools, skills and approaches</em></h1>
  <p class="lede">A Fabric case study with Cowork, Astra and six authoring approaches.</p>
  <div class="cover-flow"><span>Evidence</span><b>&rarr;</b><span>Reasoning</span><b>&rarr;</b><span>Editable diagrams</span></div>
  <p class="footnote">A practical comparison of architecture-diagramming approaches.</p>
  <aside class="notes">This is a practitioner story, not a model benchmark. We will introduce the options and a sample prompt, then see the supplied Cowork output and the six recent Fabric batch diagrams, ending with CSA style. The deck follows the GitHub Brand Toolkit's neutral/green palette and Mona Sans typography; it is an independent presentation, not an endorsement.</aside>
</section>
<section id="options">
  <p class="eyebrow">01 / The options</p><h2>Choose the approach for the job.</h2>
  <table class="option-table">
    <thead><tr><th>Skill or approach</th><th>Origin / source</th><th>Best suited for</th></tr></thead>
    <tbody>
      <tr><td>Cowork</td><td></td><td>Research and multi-step document creation</td></tr>
      <tr><td>Azure Diagrams</td><td>Community / cmb211087<span class="source-links"><a href="https://github.com/cmb211087/azure-diagrams-skill/tree/d7513005f62ad8042c36987cd7da515a114701d1/skills/azure-diagrams" target="_blank" rel="noopener noreferrer">Original skill</a> (not Microsoft)</span></td><td>Repeatable Azure infrastructure diagrams</td></tr>
      <tr><td>Excalidraw</td><td>Community / coleam00<span class="source-links"><a href="https://github.com/coleam00/excalidraw-diagram-skill/tree/8646fcc9f74f38539c6cdb4c969723336a96ddcd" target="_blank" rel="noopener noreferrer">Original skill</a></span></td><td>Workshops, whiteboarding and explanations</td></tr>
      <tr><td>Aymen: pitch + iterate</td><td>Community / aymenfurter<span class="source-links">Original skills: <a href="https://github.com/aymenfurter/skills/tree/071fa8835d0ffe0bb72a54573a465672fc7ba8cc/skills/drawio-pitch" target="_blank" rel="noopener noreferrer">Pitch</a> / <a href="https://github.com/aymenfurter/skills/tree/071fa8835d0ffe0bb72a54573a465672fc7ba8cc/skills/drawio-iterate" target="_blank" rel="noopener noreferrer">Iterate</a></span></td><td>Dense, research-led architecture proposals</td></tr>
      <tr><td>Mermaid</td><td>Community / softaworks<span class="source-links"><a href="https://github.com/softaworks/agent-toolkit/tree/3027f20f3181758385a1bb8c022d4041dfb4de84/skills/mermaid-diagrams" target="_blank" rel="noopener noreferrer">Original skill</a></span></td><td>Flows, sequences and docs alongside code</td></tr>
      <tr><td>Astra + draw.io</td><td>No skill / direct prompting<span class="source-links"><a href="https://www.drawio.com/" target="_blank" rel="noopener noreferrer">draw.io tool</a> (no original skill)</span></td><td>One-off diagrams with human feedback</td></tr>
      <tr><td>CSA style <span class="new-skill-label">New skill created</span></td><td>Custom / suzungg<span class="source-links"><a href="${repo}/tree/main/skills/csa-style-diagrams" target="_blank" rel="noopener noreferrer">Original skill</a> (not Microsoft)</span></td><td>Azure, Fabric and Foundry reference diagrams</td></tr>
    </tbody>
  </table>
  <div class="model-line"><span><strong>Astra</strong> for the skills</span><span>Shared MCPs: <strong>Microsoft Learn + GitHub</strong></span></div>
  <aside class="notes">Cowork is a product/workspace, not a peer diagram notation. The six other rows are authoring approaches used in our Astra-led session. Aymen pitch and iterate are two original skills used together in one approach. Astra + draw.io is the deliberate no-skill baseline, not a missing installation. Shared MCPs refers to the toolkit's common content-research setup, not independently verified use of both servers for every output; official web retrieval and GitHub CLI were also used. Excalidraw skill guidance is externally referenced because its separate repository has no explicit license; it is not bundled. These use cases are practical suggestions, not rankings. The supplied Cowork screenshot does not record an exact Claude model/version. Anthropic's current Cowork page says the capabilities are being integrated into Claude; Cowork is retained here as the user's workflow label. Source: https://claude.com/product/cowork.</aside>
</section>
<section id="demo" class="demo">
  <p class="eyebrow">02 / Demo</p><h2>Sample prompt</h2>
  <blockquote class="demo-prompt">Draw an architecture for Fabric's end-to-end data science</blockquote>
  <aside class="notes">Use this short sample prompt to introduce the demo. The six Astra outputs used a more detailed common batch brief with 15 components and 17 relationships, retained in downloads/fabric-six-approaches.zip. The supplied Cowork image has a broader scope; this sample prompt is not a claim that every output was generated from exactly these words alone.</aside>
</section>`;

const diagrams = [
  {id:'cowork', title:'Cowork', image:'cowork.png',
   notes:'The user supplied this image as the Cowork result. It is preserved byte-for-byte, not recreated or technically endorsed. It includes a single workspace/capacity framing, multiple ingestion options, OneLake layers, notebooks/MLflow, batch scoring, online model endpoints, AI functions, BI and governance. Its scope and prompt differ from the 15-component batch brief. We cannot infer the exact Claude model, plugins, prompts, MCP calls, source fidelity or generation cost from the screenshot. Only a PNG was supplied; no native editable Cowork source is claimed. Treat detailed capability statements as assertions to verify for a concrete design.'},
  {id:'azure', title:'Azure Diagrams', model:'Astra / Python + Graphviz', image:'azure.png',
   caption:'Good fit: repeatable, code-generated infrastructure and data-platform views.',
   notes:'The original Python diagrams generator and Graphviz source are retained. The Azure Diagrams skill was applied directly from the repository. For this Fabric workload, official Fabric icons were used rather than substituting Azure ML services. Invisible Graphviz edges constrain layout only; the 17 visible relationships come from the common contract. Automatic layout needed several revisions for ordering, whitespace and captions. This is code-editable, not native drag-and-drop draw.io. The standalone PNG is easiest to share; retain accompanying icons for the SVG.'},
  {id:'excalidraw', title:'Excalidraw', model:'Astra / Editable explanatory canvas', image:'excalidraw.png',
   caption:'Good fit: workshops, explanations and collaborative architecture discussions.',
   notes:'The scene was hand-authored in sections using pinned upstream guidance, then normalized and exported with the Excalidraw application library. Its clean styling follows that guidance; sketch-like roughness is not mandatory. A custom prediction-record example makes the output concrete without presenting it as a built-in Fabric schema. This version has the same 15 components and 17 relationships. No unlicensed skill source was copied into the toolkit or deliverable. The independent browser exporter downloaded remote libraries; local rendering does not mean all processing or model inference was offline.'},
  {id:'aymen', title:'Aymen: pitch + iterate', model:'Astra / Research-led A5 pitch', image:'aymen.png',
   caption:'Four image-review passes retained. Growth gate: 2.32x achieved; 9x required.',
   notes:'Two GPT-6 Astra research contexts covered ingestion/training and scoring/consumption before the pitch. The original skills prescribe A5, meaningful ninefold XML growth before correction passes, and at least four reviews. This latest run completed four review passes but reached only 38,303 / 16,500 = 2.3214x meaningful pass-1 XML. It continued past the unmet gate as a documented deviation, not full original-skill compliance. Do not confuse this run with the earlier MLOps comparison where the user expressly waived the growth rule. We did not modify the original skills or add padding to satisfy a quota. Small A5 annotations need enlargement. Sources and all review pairs are in the bundle.'},
  {id:'mermaid', title:'Mermaid', model:'Astra / Diagram-as-text', image:'mermaid.png', portrait:true,
   caption:'Good fit: flows and architecture documentation that live beside code.',
   notes:'The full portrait flow is shown on the left; the right image is a clearly labeled crop from the same PNG for slide readability. No components have been removed from the underlying diagram. Click either image for the full scrollable original. Mermaid is easy to review as text and regenerate, but automatic layout and dense long flows are less suited to a single landscape slide. The native .mmd, SVG and PNG are in the source ZIP. This is the general Mermaid-diagrams skill, not the earlier Pretty Mermaid renderer comparison.'},
  {id:'baseline', title:'Astra + draw.io', model:'No diagram skill / Clear brief + human review', image:'baseline.png',
   caption:'Good fit: occasional diagrams where a clear brief and feedback are enough.',
   notes:'A fresh independent context received the common brief but was prohibited from reading diagram skills, examples, helpers or sibling outputs. It created native draw.io shapes and attached connectors. The parent then exported using the common local draw.io application and requested one small annotation move after visual inspection. Using an export wrapper is not the same as skill-guided source generation. This is a credible baseline, not an intentionally weak straw man. A strong result does not prove that skills never help.'},
  {id:'csa', title:'CSA style', model:'Astra / Reusable technical-reference workflow', image:'csa.png',
   caption:'Good fit: consistent, editable Fabric, Foundry and Azure reference diagrams.',
   notes:'This current official-icon Fabric example was regenerated with the CSA helpers; it was not a new independent invention. That reuse is one intended benefit of a package with examples. The style is inspired by the Microsoft Azure Architecture Center: service icons, purposeful section bands, meaningful workflow numbers and perimeter feedback. Logical phases are distinct from workspace ownership. It is an independently authored skill, not an official Microsoft diagram standard or endorsement.'}
];
function imageButton(item, image = item.image) {
  return `<button type="button" class="diagram-trigger" data-image="assets/${item.image}" data-title="${item.title}" aria-label="Open full-size ${item.title} diagram"><img src="assets/${image}" alt="${item.title} Fabric architecture${image !== item.image ? ' detail crop' : ''}"></button>`;
}
function diagramSlide(item, index) {
  return `<section id="${item.id}" class="diagram"><h2>${String(index + 1).padStart(2,'0')} / ${item.title}</h2>${item.model ? `<p class="subhead">${item.model}</p>` : ''}
  ${item.portrait ? `<div class="portrait-pair"><div><p class="image-label">Complete flow</p>${imageButton(item)}</div><div><p class="image-label">Detail / training, selection and scoring</p>${imageButton(item,'mermaid-detail.png')}</div></div>` : imageButton(item)}
  ${item.caption ? `<p class="diagram-caption"><span>${item.caption}</span></p>` : ''}<aside class="notes">${item.notes}</aside></section>`;
}

document.getElementById('slides').innerHTML = intro + diagrams.map(diagramSlide).join('');
const viewer = document.getElementById('diagram-viewer');
const viewerImage = document.getElementById('viewer-image');
const viewport = document.querySelector('.viewer-scroll');
let imageWidth = 1000;
let returnFocus;
function setWidth(width) {
  imageWidth = Math.max(1, Math.min(12000, width));
  viewerImage.style.width = `${imageWidth}px`;
}
function readableWidth() {
  setWidth(Math.min(viewerImage.naturalWidth || 1600, Math.max(900, viewport.clientWidth - 40)));
}
function fitImage() {
  const ratio = viewerImage.naturalWidth / viewerImage.naturalHeight;
  if (!Number.isFinite(ratio)) return;
  setWidth(Math.min(viewport.clientWidth - 40, (viewport.clientHeight - 40) * ratio));
  viewport.scrollTo(0, 0);
}
document.querySelectorAll('.diagram-trigger').forEach(button => button.addEventListener('click', () => {
  returnFocus = button;
  document.getElementById('viewer-title').textContent = button.dataset.title;
  viewerImage.alt = button.dataset.title;
  viewerImage.onload = () => { readableWidth(); viewport.scrollTo(0, 0); };
  viewer.showModal();
  viewerImage.src = button.dataset.image;
  document.getElementById('close-viewer').focus();
}));
document.getElementById('close-viewer').addEventListener('click', () => viewer.close());
document.getElementById('zoom-in').addEventListener('click', () => setWidth(imageWidth * 1.3));
document.getElementById('zoom-out').addEventListener('click', () => setWidth(imageWidth / 1.3));
document.getElementById('zoom-fit').addEventListener('click', fitImage);
document.getElementById('zoom-readable').addEventListener('click', readableWidth);
viewer.addEventListener('keydown', event => event.stopPropagation());
viewer.addEventListener('close', () => returnFocus?.focus());
viewer.addEventListener('click', event => { if (event.target === viewer) viewer.close(); });
Reveal.initialize({
  width:1600,height:900,margin:.025,minScale:.15,maxScale:2,center:false,hash:true,
  scrollActivationWidth:0,controls:true,controlsTutorial:false,controlsLayout:'edges',
  progress:true,slideNumber:'c/t',transition:matchMedia('(prefers-reduced-motion: reduce)').matches?'none':'fade',
  transitionSpeed:'fast',backgroundTransition:'none',keyboardCondition:()=>!viewer.open,plugins:[RevealNotes]
});
document.getElementById('overview').addEventListener('click', () => Reveal.toggleOverview());
